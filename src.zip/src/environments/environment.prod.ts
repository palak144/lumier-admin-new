export const environment = {
  production: true,
  APIEndpoint: 'http://18.141.13.208/api/v1/'
};
