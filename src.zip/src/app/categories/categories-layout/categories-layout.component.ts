import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-categories-layout',
  templateUrl: './categories-layout.component.html',
  styleUrls: ['./categories-layout.component.scss']
})
export class CategoriesLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
