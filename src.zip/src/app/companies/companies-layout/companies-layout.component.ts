import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-companies-layout',
  templateUrl: './companies-layout.component.html',
  styleUrls: ['./companies-layout.component.scss']
})
export class CompaniesLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
