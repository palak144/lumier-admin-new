import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setting-layout',
  templateUrl: './setting-layout.component.html',
  styleUrls: ['./setting-layout.component.scss']
})
export class SettingLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
