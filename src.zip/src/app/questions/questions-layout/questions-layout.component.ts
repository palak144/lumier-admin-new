import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-questions-layout',
  templateUrl: './questions-layout.component.html',
  styleUrls: ['./questions-layout.component.scss']
})
export class QuestionsLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
