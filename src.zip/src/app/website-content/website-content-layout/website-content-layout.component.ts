import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-website-content-layout',
  templateUrl: './website-content-layout.component.html',
  styleUrls: ['./website-content-layout.component.scss']
})
export class WebsiteContentLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
